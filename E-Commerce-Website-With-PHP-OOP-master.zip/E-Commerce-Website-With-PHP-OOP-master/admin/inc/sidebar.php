<div class="grid_2">
    <div class="box sidemenu">
        <div class="block" id="section-menu">
            <ul class="section menu">
               <li><a class="menuitem">Option du site</a>
                    <ul class="submenu">
                        <li><a href="titleslogan.php">Title & Slogan</a></li>
                        <li><a href="social.php">Réseau</a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        
                    </ul>
                </li>
				
                 <li><a class="menuitem">Mettre à jour</a>
                    <ul class="submenu">
                        <li><a>à propos </a></li>
                        <li><a>Nous contacter</a></li>
                    </ul>
                </li>
				<li><a class="menuitem">Slider Option</a>
                    <ul class="submenu">
                        <li><a href="slideradd.php">Add Slider</a> </li>
                        <li><a href="sliderlist.php">Slider List</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Category Option</a>
                    <ul class="submenu">
                        <li><a href="catadd.php">Ajouter une catégorie</a> </li>
                        <li><a href="catlist.php">Liste des catégories</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Option des marques</a>
                    <ul class="submenu">
                        <li><a href="brandadd.php">Ajouter une marque </a> </li>
                        <li><a href="brandlist.php">Liste des marques</a> </li>
                    </ul>
                </li>
                <li><a class="menuitem">Product Option</a>
                    <ul class="submenu">
                        <li><a href="productadd.php">Add Product</a> </li>
                        <li><a href="productlist.php">Product List</a> </li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
