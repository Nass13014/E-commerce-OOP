<?php include 'inc/header.php'; ?>
<?php 
$login = Session::get("cuslogin");
if ($login == true) {
    header("Location:order.php");
}
 ?>
<?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $custLogin = $cmr->customerLogin($_POST);
}
?>
 <div class="main">
    <div class="content">
    	 <div class="login_panel">
    	 	<?php 
            if (isset($custLogin)) {
                echo $custLogin;
            }
             ?>
        	<h3>Déja client ? </h3>
        	<p>Connectez vous à partir du formulaire ci-dessous</p>
        	<form action="" method="post">
                	<input name="email" placeholder="Email" type="text"/>
                    <input name="pass" placeholder="Password" type="password"/>
                 
                 <p class="note">Si vous avez oublier votre mdp entrez votre mail et cliquez  <a href="#">here</a></p>
                    <div class="buttons"><div><button class="grey" name="login">Se connecter</button></div></div>
                    </div>
                    </form>
                    <?php 

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $customerReg = $cmr->customerRegistration($_POST);
}
?>
    	<div class="register_account">
    		<?php 
            if (isset($customerReg)) {
                echo $customerReg;
            }
             ?>
    		<h3>Créer un compte</h3>
    		<form action="" method="post">
		   			 <table>
		   				<tbody>
						<tr>
						<td>
							<div>
							<input type="text" name="name" placeholder="Nom"/>
							</div>
							<div>
							<input type="text" name="address" placeholder="Addresse"/>
							</div>
							
							<div>
							   <input type="text" name="city" placeholder="Ville"/>
							</div>
							
							<div>
								<input type="text" name="zip" placeholder="Code Postal"/>
							</div>
							
		    			 </td>
		    			<td>
		    				<div>
								<input type="text" name="email" placeholder="Email"/>
							</div>
						<div>
							<input type="text" name="country" placeholder="Pays"/>
						</div>
		    			        
	
		           <div>
		          <input type="text" name="phone" placeholder="téléphone"/>
		          </div>
				  
				  <div>
					<input type="text" name="pass" placeholder="Mot de passe"/>
				</div>
		    	</td>
		    </tr> 
		    </tbody></table> 
		   <div class="search"><div><button class="grey" name="register">Créer un compte</button></div></div>
		    <p class="terms">En cliquant sur "Créer un compte" vous acceptez les <a href="#">Termes  &amp; Conditions</a>.</p>
		    <div class="clear"></div>
		    </form>
    	</div>  	
       <div class="clear"></div>
    </div>
 </div>
<?php include 'inc/footer.php'; ?>

